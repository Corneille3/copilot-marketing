import { Suspense } from "react";
import type { Metadata } from "next";
import { Nav } from "@/components/ui/Nav";
import { Footer } from "@/components/ui/Footer";
import { ContactForm } from "@/components/sections/ContactForm";

export const metadata: Metadata = {
  title: "Contact",
  description:
    "Tell us about your project, staffing need, or general inquiry. We reply within two business days.",
};

export default function ContactPage() {
  return (
    <>
      <Nav />
      <main className="min-h-screen pt-20 bg-bone text-ink selection:bg-sienna selection:text-bone">
        {/* HERO */}
        <section className="border-b border-rule">
          <div className="mx-auto max-w-7xl px-6 py-24 lg:px-12 lg:py-40">
            <div className="grid gap-12 lg:grid-cols-12">
              <div className="lg:col-span-3">
                <div className="flex items-center gap-3 text-xs uppercase tracking-[0.2em] text-muted">
                  <span className="inline-block h-px w-8 bg-muted" />
                  <span>Contact</span>
                </div>
              </div>
              <div className="lg:col-span-9">
                <h1 className="font-display text-5xl font-light leading-[1.05] tracking-tight md:text-6xl lg:text-7xl">
                  Tell us what
                  <br />
                  you&apos;re <span className="italic text-sienna">working on.</span>
                </h1>
                <p className="mt-10 max-w-2xl text-lg text-muted md:text-xl">
                  We&apos;ll reply within two business days with either a direct response, a few
                  clarifying questions, or an honest &quot;we&apos;re not the right fit, here&apos;s
                  who might be.&quot;
                </p>
              </div>
            </div>
          </div>
        </section>

        {/* FORM */}
        <section className="border-b border-rule">
          <div className="mx-auto max-w-7xl px-6 py-24 lg:px-12 lg:py-32">
            <div className="grid gap-12 lg:grid-cols-12">
              <div className="lg:col-span-3">
                <p className="font-mono text-xs uppercase tracking-[0.2em] text-sienna">
                  — Get in touch
                </p>
              </div>
              <div className="lg:col-span-9">
                <Suspense fallback={<div className="h-96 animate-pulse bg-rule/30" />}>
                  <ContactForm />
                </Suspense>
              </div>
            </div>
          </div>
        </section>

        {/* OTHER WAYS */}
        <section className="border-b border-rule">
          <div className="mx-auto max-w-7xl px-6 py-24 lg:px-12 lg:py-32">
            <div className="grid gap-12 lg:grid-cols-12">
              <div className="lg:col-span-3">
                <p className="font-mono text-xs uppercase tracking-[0.2em] text-sienna">
                  — Other ways
                </p>
              </div>
              <div className="lg:col-span-9">
                <h2 className="font-display text-3xl font-light tracking-tight md:text-4xl">
                  Other ways to reach us.
                </h2>
                <div className="mt-12 grid gap-12 md:grid-cols-3">
                  <ContactDetail
                    label="Email"
                    value="hello@kouamvision.com"
                    href="mailto:hello@kouamvision.com"
                  />
                  <ContactDetail label="Based in" value="Toronto, Ontario" />
                  <ContactDetail label="Serving" value="Clients across Canada" />
                </div>
              </div>
            </div>
          </div>
        </section>

        {/* WHAT HAPPENS NEXT */}
        <section className="border-b border-rule bg-ink text-bone">
          <div className="mx-auto max-w-7xl px-6 py-24 lg:px-12 lg:py-32">
            <div className="grid gap-12 lg:grid-cols-12">
              <div className="lg:col-span-3">
                <p className="font-mono text-xs uppercase tracking-[0.2em] text-sienna">
                  — Process
                </p>
              </div>
              <div className="lg:col-span-9">
                <h2 className="font-display text-3xl font-light tracking-tight md:text-4xl">
                  What happens next.
                </h2>
                <div className="mt-12 grid gap-10 md:grid-cols-3">
                  <Next
                    number="01"
                    body="We read every message personally — no automated routing."
                  />
                  <Next
                    number="02"
                    body="You'll hear back within two business days with a direct response, clarifying questions, or an honest fit assessment."
                  />
                  <Next
                    number="03"
                    body="If there's a fit, we'll propose a 30-minute discovery call (no cost) to scope the next step."
                  />
                </div>
              </div>
            </div>
          </div>
        </section>
      </main>
      <Footer />
    </>
  );
}

function ContactDetail({
  label,
  value,
  href,
}: {
  label: string;
  value: string;
  href?: string;
}) {
  const content = (
    <>
      <p className="font-mono text-[10px] uppercase tracking-wider text-muted">{label}</p>
      <p className="mt-3 font-display text-xl">{value}</p>
    </>
  );
  if (href) {
    return (
      <a href={href} className="block transition-colors hover:text-sienna">
        {content}
      </a>
    );
  }
  return <div>{content}</div>;
}

function Next({ number, body }: { number: string; body: string }) {
  return (
    <div className="border-t border-bone/20 pt-6">
      <span className="font-mono text-xs text-sienna">— {number}</span>
      <p className="mt-4 leading-relaxed text-bone/80">{body}</p>
    </div>
  );
}
