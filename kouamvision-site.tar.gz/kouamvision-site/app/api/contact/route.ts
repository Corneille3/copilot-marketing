import { NextRequest, NextResponse } from "next/server";
import { Resend } from "resend";

// Simple in-memory rate limit (per server instance).
// For production at scale, swap for Upstash Redis or similar.
const RATE_LIMIT_WINDOW_MS = 60 * 60 * 1000; // 1 hour
const RATE_LIMIT_MAX = 5; // 5 submissions / hour / IP
const ipBuckets = new Map<string, number[]>();

function rateLimit(ip: string): boolean {
  const now = Date.now();
  const bucket = ipBuckets.get(ip)?.filter((t) => now - t < RATE_LIMIT_WINDOW_MS) || [];
  if (bucket.length >= RATE_LIMIT_MAX) return false;
  bucket.push(now);
  ipBuckets.set(ip, bucket);
  return true;
}

type Intent = "demo" | "project" | "staffing" | "general";

interface Payload {
  intent: Intent;
  name: string;
  email: string;
  organization?: string;
  // demo
  role?: string;
  firm_size?: string;
  use_case?: string;
  preferred_time?: string;
  demo_notes?: string;
  // project
  project_description?: string;
  budget?: string;
  timeline?: string;
  // staffing (also uses role)
  location?: string;
  engagement?: string;
  start_date?: string;
  notes?: string;
  // general
  message?: string;
  // shared
  referral?: string;
  // honeypot
  website?: string;
}

function isValidEmail(email: string): boolean {
  return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email);
}

function validate(payload: Payload): string | null {
  if (!payload.intent || !["demo", "project", "staffing", "general"].includes(payload.intent))
    return "Invalid intent";
  if (!payload.name || payload.name.length < 2) return "Name is required";
  if (!payload.email || !isValidEmail(payload.email)) return "Valid email is required";

  if (payload.intent === "demo") {
    if (!payload.role) return "Role is required";
    if (!payload.firm_size) return "Firm size is required";
    if (!payload.use_case) return "Primary use case is required";
  }
  if (payload.intent === "project") {
    if (!payload.project_description || payload.project_description.length < 10)
      return "Project description is required";
    if (!payload.budget) return "Budget range is required";
  }
  if (payload.intent === "staffing") {
    if (!payload.role) return "Role is required";
    if (!payload.location) return "Location is required";
    if (!payload.engagement) return "Engagement type is required";
  }
  if (payload.intent === "general") {
    if (!payload.message || payload.message.length < 10) return "Message is required";
  }
  return null;
}

function escape(s: string): string {
  return s
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;")
    .replace(/'/g, "&#039;");
}

function buildEmail(p: Payload): { subject: string; html: string; text: string } {
  const intentLabels: Record<Intent, string> = {
    demo: "ComplianceIQ demo request",
    project: "Project inquiry",
    staffing: "Staffing request",
    general: "General inquiry",
  };
  const subject = `[${intentLabels[p.intent]}] ${p.name}${p.organization ? " — " + p.organization : ""}`;

  const fields: [string, string | undefined][] = [
    ["Intent", intentLabels[p.intent]],
    ["Name", p.name],
    ["Email", p.email],
    ["Organization", p.organization],
    // demo
    ["Role", p.role],
    ["Firm size", p.firm_size],
    ["Primary use case", p.use_case],
    ["Preferred time", p.preferred_time],
    ["Demo notes", p.demo_notes],
    // project
    ["Project description", p.project_description],
    ["Budget", p.budget],
    ["Timeline", p.timeline],
    // staffing
    ["Location", p.location],
    ["Engagement", p.engagement],
    ["Start date", p.start_date],
    ["Notes", p.notes],
    // general
    ["Message", p.message],
    ["How they heard about us", p.referral],
  ];

  const filled = fields.filter(([, v]) => v && v.trim().length > 0) as [string, string][];

  const text = filled.map(([k, v]) => `${k}: ${v}`).join("\n\n");
  const html = `
    <div style="font-family:system-ui,-apple-system,sans-serif;max-width:600px;color:#1c1b17;background:#f5f1e8;padding:24px;border-radius:8px;">
      <h2 style="font-size:18px;margin:0 0 16px;color:#b84a2e;">${escape(intentLabels[p.intent])}</h2>
      <table style="width:100%;border-collapse:collapse;font-size:14px;">
        ${filled
          .map(
            ([k, v]) => `
              <tr>
                <td style="padding:8px 12px 8px 0;color:#6b665c;font-weight:500;vertical-align:top;width:160px;">${escape(k)}</td>
                <td style="padding:8px 0;color:#1c1b17;white-space:pre-wrap;">${escape(v)}</td>
              </tr>`,
          )
          .join("")}
      </table>
      <p style="margin-top:24px;font-size:12px;color:#6b665c;">Sent from kouamvision.com contact form.</p>
    </div>`;

  return { subject, html, text };
}

export async function POST(req: NextRequest) {
  try {
    // Rate limit
    const ip =
      req.headers.get("x-forwarded-for")?.split(",")[0].trim() ||
      req.headers.get("x-real-ip") ||
      "unknown";
    if (!rateLimit(ip)) {
      return NextResponse.json(
        { error: "Too many submissions. Please try again later." },
        { status: 429 },
      );
    }

    const payload = (await req.json()) as Payload;

    // Honeypot — silently succeed if filled (bot)
    if (payload.website && payload.website.length > 0) {
      return NextResponse.json({ success: true });
    }

    const validationError = validate(payload);
    if (validationError) {
      return NextResponse.json({ error: validationError }, { status: 400 });
    }

    const apiKey = process.env.RESEND_API_KEY;
    const toEmail = process.env.CONTACT_TO_EMAIL;
    const fromEmail = process.env.CONTACT_FROM_EMAIL;

    if (!apiKey || !toEmail || !fromEmail) {
      console.error("Contact form misconfigured: missing RESEND_API_KEY/CONTACT_TO_EMAIL/CONTACT_FROM_EMAIL");
      return NextResponse.json(
        { error: "Contact form is temporarily unavailable. Please email us directly." },
        { status: 500 },
      );
    }

    const resend = new Resend(apiKey);
    const { subject, html, text } = buildEmail(payload);

    const { error } = await resend.emails.send({
      from: `JKOUAM Contact <${fromEmail}>`,
      to: [toEmail],
      replyTo: payload.email,
      subject,
      html,
      text,
    });

    if (error) {
      console.error("Resend error:", error);
      return NextResponse.json({ error: "Failed to send message" }, { status: 500 });
    }

    return NextResponse.json({ success: true });
  } catch (err) {
    console.error("Contact API error:", err);
    return NextResponse.json({ error: "Server error" }, { status: 500 });
  }
}
