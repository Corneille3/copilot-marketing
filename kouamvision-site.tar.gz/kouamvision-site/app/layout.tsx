import type { Metadata } from "next";
import { Fraunces, IBM_Plex_Sans, IBM_Plex_Mono } from "next/font/google";
import "./globals.css";

const fraunces = Fraunces({
  subsets: ["latin"],
  variable: "--font-display",
  display: "swap",
  axes: ["opsz", "SOFT"],
});

const ibmPlexSans = IBM_Plex_Sans({
  subsets: ["latin"],
  weight: ["300", "400", "500", "600"],
  variable: "--font-body",
  display: "swap",
});

const ibmPlexMono = IBM_Plex_Mono({
  subsets: ["latin"],
  weight: ["400", "500"],
  variable: "--font-mono",
  display: "swap",
});

const SITE_URL = process.env.NEXT_PUBLIC_SITE_URL || "https://kouamvision.com";

export const metadata: Metadata = {
  title: {
    default: "JKOUAM Consultancy — AI, Custom Software & Bilingual IT Staffing",
    template: "%s · JKOUAM Consultancy",
  },
  description:
    "Toronto-based technology firm. We build production AI and custom software, and help organizations find bilingual IT support talent across Canada.",
  metadataBase: new URL(SITE_URL),
  openGraph: {
    title: "JKOUAM Consultancy — AI, Custom Software & Bilingual IT Staffing",
    description:
      "Toronto-based technology firm. We build production AI and custom software, and help organizations find bilingual IT support talent across Canada.",
    url: SITE_URL,
    siteName: "JKOUAM Consultancy",
    locale: "en_CA",
    type: "website",
  },
  alternates: { canonical: SITE_URL },
  robots: { index: true, follow: true },
};

const organizationSchema = {
  "@context": "https://schema.org",
  "@type": "ProfessionalService",
  name: "JKOUAM Consultancy Inc.",
  url: SITE_URL,
  description:
    "Toronto-based technology firm building production AI, custom software, and providing bilingual IT support staffing across Canada.",
  address: {
    "@type": "PostalAddress",
    addressLocality: "Toronto",
    addressRegion: "ON",
    addressCountry: "CA",
  },
  areaServed: { "@type": "Country", name: "Canada" },
  serviceType: ["AI Software Development", "Custom Software Development", "IT Staffing"],
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html
      lang="en"
      className={`${fraunces.variable} ${ibmPlexSans.variable} ${ibmPlexMono.variable}`}
    >
      <head>
        <script
          type="application/ld+json"
          dangerouslySetInnerHTML={{ __html: JSON.stringify(organizationSchema) }}
        />
      </head>
      <body className="font-body antialiased">{children}</body>
    </html>
  );
}
