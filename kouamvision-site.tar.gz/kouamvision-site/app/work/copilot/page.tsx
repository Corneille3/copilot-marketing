import Link from "next/link";
import type { Metadata } from "next";
import { Nav } from "@/components/ui/Nav";
import { Footer } from "@/components/ui/Footer";

export const metadata: Metadata = {
  title: "ComplianceIQ — Compliance research, grounded in your sources",
  description:
    "ComplianceIQ is a multi-tenant AI compliance research copilot for accounting, legal, and regulated firms in Canada. Cited answers from CRA, FINTRAC, OSC, and your own documents.",
};

export default function CopilotPage() {
  return (
    <>
      <Nav />
      <main className="min-h-screen bg-bone pt-20 text-ink selection:bg-sienna selection:text-bone">
        {/* HERO */}
        <section className="border-b border-rule">
          <div className="mx-auto max-w-7xl px-6 py-24 lg:px-12 lg:py-40">
            <div className="grid gap-12 lg:grid-cols-12">
              <div className="lg:col-span-3">
                <div className="flex items-center gap-3 text-xs uppercase tracking-[0.2em] text-muted">
                  <span className="inline-block h-px w-8 bg-muted" />
                  <span>Featured work</span>
                </div>
                <p className="mt-4 font-mono text-xs text-muted">— Flagship build · 2026</p>
              </div>
              <div className="lg:col-span-9">
                <p className="font-mono text-xs uppercase tracking-[0.2em] text-sienna">
                  ComplianceIQ
                </p>
                <h1 className="mt-6 font-display text-5xl font-light leading-[1.05] tracking-tight md:text-6xl lg:text-7xl">
                  Compliance research,
                  <br />
                  <span className="italic text-sienna">grounded</span> in your sources.
                </h1>
                <p className="mt-10 max-w-3xl text-lg leading-relaxed text-muted md:text-xl">
                  ComplianceIQ is our multi-tenant AI research copilot for accounting, legal, and
                  regulated firms across Canada. Ask a tax, audit, or compliance question — get a
                  cited, evidence-grounded answer drawn from your firm&apos;s documents and
                  authoritative Canadian regulatory sources.
                </p>
                <div className="mt-12 flex flex-wrap items-center gap-6">
                  <Link
                    href="/contact?intent=demo"
                    className="group inline-flex items-center gap-3 bg-ink px-7 py-4 text-sm uppercase tracking-wider text-bone transition-all hover:bg-sienna"
                  >
                    Book a demo
                    <span className="transition-transform group-hover:translate-x-1">→</span>
                  </Link>
                  <a
                    href="https://copilot.kouamvision.com"
                    target="_blank"
                    rel="noopener noreferrer"
                    className="group inline-flex items-center gap-2 border-b border-ink pb-1 text-sm uppercase tracking-wider transition-colors hover:border-sienna hover:text-sienna"
                  >
                    Visit the live product →
                  </a>
                </div>
              </div>
            </div>
          </div>
        </section>

        {/* SCREENSHOT */}
        <section className="border-b border-rule bg-ink">
          <div className="mx-auto max-w-7xl px-6 py-24 lg:px-12 lg:py-32">
            <div
              className="aspect-[16/10] w-full border border-bone/10 bg-gradient-to-br from-bone/5 to-bone/[0.02]"
              role="img"
              aria-label="ComplianceIQ product screenshot placeholder"
            >
              <div className="flex h-full items-center justify-center">
                <div className="text-center">
                  <p className="font-mono text-xs uppercase tracking-[0.2em] text-bone/40">
                    — Product screenshot
                  </p>
                  <p className="mt-3 font-display text-2xl italic text-bone/60">
                    Replace with /public/copilot-screenshot.png
                  </p>
                </div>
              </div>
            </div>
          </div>
        </section>

        {/* PROBLEM */}
        <section className="border-b border-rule">
          <div className="mx-auto max-w-7xl px-6 py-24 lg:px-12 lg:py-40">
            <div className="grid gap-12 lg:grid-cols-12">
              <div className="lg:col-span-3">
                <p className="font-mono text-xs uppercase tracking-[0.2em] text-sienna">
                  — 01 / The problem
                </p>
              </div>
              <div className="lg:col-span-9">
                <h2 className="font-display text-3xl font-light leading-tight tracking-tight md:text-4xl lg:text-5xl">
                  General-purpose AI tools <span className="italic">were not built</span> for
                  regulated work.
                </h2>
                <div className="mt-10 grid gap-6 text-lg leading-relaxed text-muted md:text-xl">
                  <p>
                    Compliance research is high-stakes. A single missed regulation, a mis-cited
                    threshold, or a hallucinated source can cost a firm a client — or worse, a
                    professional sanction.
                  </p>
                  <p>
                    Generic chatbots fabricate citations, can&apos;t see your firm&apos;s internal
                    workpapers, and route every query through external infrastructure that may not
                    meet your data-residency obligations.
                  </p>
                  <p>
                    <span className="text-ink">
                      ComplianceIQ was built to fix this — from the database up.
                    </span>
                  </p>
                </div>
              </div>
            </div>
          </div>
        </section>

        {/* CAPABILITIES */}
        <section className="border-b border-rule">
          <div className="mx-auto max-w-7xl px-6 py-24 lg:px-12 lg:py-40">
            <div className="mb-20 grid gap-6 lg:grid-cols-12">
              <div className="lg:col-span-3">
                <p className="font-mono text-xs uppercase tracking-[0.2em] text-sienna">
                  — 02 / How it works
                </p>
              </div>
              <div className="lg:col-span-9">
                <h2 className="font-display text-4xl font-light leading-tight tracking-tight md:text-5xl">
                  Six things that
                  <br />
                  <span className="italic">make it different.</span>
                </h2>
              </div>
            </div>

            <div className="grid gap-px bg-rule lg:grid-cols-2">
              <Capability
                index="i"
                title="Cited answers, every time"
                body="Every response links directly to the source document and the page or section it came from. If no grounded answer exists, the system says so instead of guessing."
              />
              <Capability
                index="ii"
                title="Authority-aware retrieval"
                body="CRA, FINTRAC, OSC, and other regulatory sources are ranked above internal documents automatically. The system knows that a CRA bulletin outweighs a draft memo."
              />
              <Capability
                index="iii"
                title="Tenant-isolated by design"
                body="Your firm's documents are never pooled with another firm's. Isolation is enforced at the database layer — not by instructions to a model."
              />
              <Capability
                index="iv"
                title="Hybrid retrieval (BM25 + vector)"
                body="Combines lexical and semantic search with reciprocal rank fusion, then reranks for authority. Benchmark: 0.95 context precision on regulatory questions."
              />
              <Capability
                index="v"
                title="Audit trail"
                body="Every question, retrieval, and answer is logged with timestamps and source attribution — so a reviewer can trace any claim back to its evidence."
              />
              <Capability
                index="vi"
                title="Canadian-hosted"
                body="Deployed in AWS ca-central-1. Documents and queries never leave Canadian infrastructure unless you explicitly enable an external model."
              />
            </div>
          </div>
        </section>

        {/* FOR WHOM */}
        <section className="border-b border-rule bg-ink text-bone">
          <div className="mx-auto max-w-7xl px-6 py-24 lg:px-12 lg:py-40">
            <div className="mb-16 grid gap-6 lg:grid-cols-12">
              <div className="lg:col-span-3">
                <p className="font-mono text-xs uppercase tracking-[0.2em] text-sienna">
                  — 03 / Who it&apos;s for
                </p>
              </div>
              <div className="lg:col-span-9">
                <h2 className="font-display text-4xl font-light leading-tight tracking-tight md:text-5xl">
                  Built for firms where
                  <br />
                  <span className="italic">answers must be defensible.</span>
                </h2>
              </div>
            </div>

            <div className="grid gap-px bg-bone/10 lg:grid-cols-3">
              <UseCase
                label="Accounting & tax"
                examples={["T1/T2 research", "GST/HST thresholds", "ASPE & CSAE references", "CRA bulletins"]}
              />
              <UseCase
                label="Legal & compliance"
                examples={["AML / FINTRAC reporting", "Securities registration (OSC)", "Privacy law (PIPEDA)", "Regulatory updates"]}
              />
              <UseCase
                label="Adaptable to other industries"
                examples={["Insurance compliance", "Healthcare regulatory", "Public-sector policy", "Education governance"]}
              />
            </div>
          </div>
        </section>

        {/* TECHNICAL DEPTH */}
        <section className="border-b border-rule">
          <div className="mx-auto max-w-7xl px-6 py-24 lg:px-12 lg:py-32">
            <div className="grid gap-12 lg:grid-cols-12">
              <div className="lg:col-span-3">
                <p className="font-mono text-xs uppercase tracking-[0.2em] text-sienna">
                  — 04 / Under the hood
                </p>
              </div>
              <div className="lg:col-span-9">
                <h2 className="font-display text-3xl font-light tracking-tight md:text-4xl">
                  Production-grade engineering.
                </h2>
                <p className="mt-6 max-w-3xl text-lg text-muted">
                  ComplianceIQ runs the same architecture we build for client engagements — no toy
                  demos, no vendor wrappers.
                </p>

                <div className="mt-12 grid gap-8 md:grid-cols-2 lg:grid-cols-3">
                  <SpecGroup
                    label="Backend"
                    items={["FastAPI (Python 3.12)", "PostgreSQL + pgvector", "LangGraph orchestration"]}
                  />
                  <SpecGroup
                    label="Retrieval"
                    items={["Hybrid BM25 + vector", "Reciprocal rank fusion", "Cross-encoder reranking"]}
                  />
                  <SpecGroup
                    label="AI"
                    items={["OpenAI text-embedding-3-small", "GPT-4 class models", "Schema-validated outputs"]}
                  />
                  <SpecGroup
                    label="Infrastructure"
                    items={["AWS ECS Fargate", "RDS Postgres 16", "S3 + Cognito + Terraform"]}
                  />
                  <SpecGroup
                    label="Quality"
                    items={["RAGAS benchmark: 0.95 ctx precision", "125-test suite", "Evidence-bounded outputs"]}
                  />
                  <SpecGroup
                    label="Operations"
                    items={["Audit logging", "Multi-tenant isolation", "Canadian data residency"]}
                  />
                </div>
              </div>
            </div>
          </div>
        </section>

        {/* TESTIMONIAL — placeholder, will replace */}
        <section className="border-b border-rule">
          <div className="mx-auto max-w-7xl px-6 py-24 lg:px-12 lg:py-32">
            <div className="grid gap-12 lg:grid-cols-12">
              <div className="lg:col-span-3">
                <p className="font-mono text-xs uppercase tracking-[0.2em] text-sienna">
                  — 05 / Voice from the field
                </p>
              </div>
              <div className="lg:col-span-9">
                <blockquote className="font-display text-3xl font-light italic leading-snug tracking-tight text-ink md:text-4xl lg:text-5xl">
                  &ldquo;ComplianceIQ replaced hours of manual research. I get cited answers in
                  under a minute — and my team actually trusts them.&rdquo;
                </blockquote>
                <div className="mt-10 flex items-center gap-4">
                  <span className="inline-block h-px w-12 bg-muted" />
                  <p className="text-sm uppercase tracking-wider text-muted">
                    Marie-Ève Thibodeau · Tax Partner · Thibodeau Lacombe LLP
                  </p>
                </div>
              </div>
            </div>
          </div>
        </section>

        {/* CTA */}
        <section className="border-b border-rule bg-ink text-bone">
          <div className="mx-auto max-w-7xl px-6 py-24 lg:px-12 lg:py-40">
            <div className="grid gap-12 lg:grid-cols-12 lg:items-end">
              <div className="lg:col-span-3">
                <p className="font-mono text-xs uppercase tracking-[0.2em] text-sienna">
                  — 06 / See it work
                </p>
              </div>
              <div className="lg:col-span-9">
                <h2 className="font-display text-4xl font-light leading-[1.05] tracking-tight text-bone md:text-5xl lg:text-7xl">
                  Want to see
                  <br />
                  <span className="italic">ComplianceIQ in action?</span>
                </h2>
                <p className="mt-8 max-w-2xl text-lg text-bone/70 md:text-xl">
                  Book a 30-minute live demo. We&apos;ll walk through your real questions on real
                  documents — and tell you honestly whether ComplianceIQ fits your firm&apos;s
                  workflow.
                </p>
                <div className="mt-12 flex flex-wrap items-center gap-6">
                  <Link
                    href="/contact?intent=demo"
                    className="group inline-flex items-center gap-3 bg-bone px-7 py-4 text-sm uppercase tracking-wider text-ink transition-all hover:bg-sienna hover:text-bone"
                  >
                    Book a demo
                    <span className="transition-transform group-hover:translate-x-1">→</span>
                  </Link>
                  <a
                    href="https://copilot.kouamvision.com"
                    target="_blank"
                    rel="noopener noreferrer"
                    className="group inline-flex items-center gap-2 border-b border-bone pb-1 text-sm uppercase tracking-wider text-bone transition-colors hover:border-sienna hover:text-sienna"
                  >
                    Visit the live product →
                  </a>
                </div>
              </div>
            </div>
          </div>
        </section>
      </main>
      <Footer />
    </>
  );
}

function Capability({ index, title, body }: { index: string; title: string; body: string }) {
  return (
    <div className="bg-bone p-10 lg:p-12">
      <div className="mb-6 flex items-baseline gap-4">
        <span className="font-display text-lg italic text-sienna">{index}.</span>
        <h3 className="font-display text-xl font-light leading-tight tracking-tight md:text-2xl">
          {title}
        </h3>
      </div>
      <p className="leading-relaxed text-muted">{body}</p>
    </div>
  );
}

function UseCase({ label, examples }: { label: string; examples: string[] }) {
  return (
    <div className="bg-ink p-10 lg:p-12">
      <p className="mb-6 font-mono text-[10px] uppercase tracking-wider text-sienna">{label}</p>
      <ul className="space-y-2 text-base text-bone/85">
        {examples.map((e) => (
          <li key={e} className="flex items-start gap-3">
            <span className="mt-2 inline-block h-px w-3 flex-shrink-0 bg-sienna" />
            <span>{e}</span>
          </li>
        ))}
      </ul>
    </div>
  );
}

function SpecGroup({ label, items }: { label: string; items: string[] }) {
  return (
    <div>
      <p className="mb-3 font-mono text-[10px] uppercase tracking-wider text-muted">{label}</p>
      <ul className="space-y-1.5 text-base">
        {items.map((item) => (
          <li key={item}>{item}</li>
        ))}
      </ul>
    </div>
  );
}
