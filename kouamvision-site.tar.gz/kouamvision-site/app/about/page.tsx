import Link from "next/link";
import type { Metadata } from "next";
import { Nav } from "@/components/ui/Nav";
import { Footer } from "@/components/ui/Footer";

export const metadata: Metadata = {
  title: "About",
  description:
    "JKOUAM Consultancy Inc. is a Toronto-based technology firm. Founded by Josi Kouam to help organizations get serious engineering without enterprise overhead.",
};

export default function AboutPage() {
  return (
    <>
      <Nav />
      <main className="min-h-screen pt-20 bg-bone text-ink selection:bg-sienna selection:text-bone">
        {/* HERO */}
        <section className="border-b border-rule">
          <div className="mx-auto max-w-7xl px-6 py-24 lg:px-12 lg:py-40">
            <div className="grid gap-12 lg:grid-cols-12">
              <div className="lg:col-span-3">
                <div className="flex items-center gap-3 text-xs uppercase tracking-[0.2em] text-muted">
                  <span className="inline-block h-px w-8 bg-muted" />
                  <span>About the firm</span>
                </div>
              </div>
              <div className="lg:col-span-9">
                <h1 className="font-display text-5xl font-light leading-[1.05] tracking-tight md:text-6xl lg:text-7xl">
                  A small Canadian
                  <br />
                  technology firm.
                  <br />
                  <span className="italic text-sienna">Built to stay useful.</span>
                </h1>
              </div>
            </div>
          </div>
        </section>

        {/* INTRO */}
        <section className="border-b border-rule">
          <div className="mx-auto max-w-7xl px-6 py-24 lg:px-12 lg:py-32">
            <div className="grid gap-12 lg:grid-cols-12">
              <div className="lg:col-span-3">
                <p className="font-mono text-xs uppercase tracking-[0.2em] text-sienna">
                  — 01 / Who we are
                </p>
              </div>
              <div className="lg:col-span-9 space-y-8 text-lg leading-relaxed text-muted md:text-xl">
                <p>
                  <span className="text-ink">JKOUAM Consultancy Inc.</span> is a Toronto-based
                  technology firm serving organizations across Canada. We help small and mid-size
                  organizations solve two kinds of problems: the software they need built, and the
                  bilingual IT talent they need to find.
                </p>
                <p>
                  We&apos;re intentionally small. That means every engagement is led by people who
                  do the work — not by account managers, sales reps, or offshore teams. It also
                  means we can only take on projects where we believe we&apos;ll genuinely add
                  value. If we can&apos;t help, we&apos;ll tell you, and usually we&apos;ll point
                  you to someone who can.
                </p>
              </div>
            </div>
          </div>
        </section>

        {/* BELIEFS */}
        <section className="border-b border-rule bg-ink text-bone">
          <div className="mx-auto max-w-7xl px-6 py-24 lg:px-12 lg:py-40">
            <div className="mb-20 grid gap-6 lg:grid-cols-12">
              <div className="lg:col-span-3">
                <p className="font-mono text-xs uppercase tracking-[0.2em] text-sienna">
                  — 02 / What we believe
                </p>
              </div>
              <div className="lg:col-span-9">
                <h2 className="font-display text-4xl font-light leading-tight tracking-tight md:text-5xl lg:text-6xl">
                  Four things we
                  <br />
                  <span className="italic">try to live by.</span>
                </h2>
              </div>
            </div>

            <div className="grid gap-16 lg:grid-cols-2 lg:gap-x-24 lg:gap-y-20">
              <Belief
                index="i"
                title="Boring where it matters"
                body="Software should be boring where it matters and clever where it counts. The clever parts are the AI model, the retrieval strategy, the user workflow. The boring parts — authentication, infrastructure, data integrity, audit trails — are where most projects quietly fail. We take both seriously."
              />
              <Belief
                index="ii"
                title="AI needs grounding"
                body="Generative AI without evidence boundaries, citations, and audit trails is a liability in any regulated context. We build AI systems the way we'd want them built if we were the ones being audited."
              />
              <Belief
                index="iii"
                title="Bilingual is a capability"
                body="We work in English and French because many of our clients' customers do. We don't translate at the end; we build that way from the start."
              />
              <Belief
                index="iv"
                title="Canadian residency matters"
                body="Not for every project — but for the ones where it matters, it really matters. We default to Canadian infrastructure and make exceptions only when clients request them."
              />
            </div>
          </div>
        </section>

        {/* FOUNDER */}
        <section className="border-b border-rule">
          <div className="mx-auto max-w-7xl px-6 py-24 lg:px-12 lg:py-40">
            <div className="grid gap-12 lg:grid-cols-12">
              <div className="lg:col-span-3">
                <p className="font-mono text-xs uppercase tracking-[0.2em] text-sienna">
                  — 03 / Founder
                </p>
              </div>
              <div className="lg:col-span-9">
                <h2 className="font-display text-4xl font-light leading-tight tracking-tight md:text-5xl">
                  <span className="italic">Josi</span> Kouam.
                </h2>
                <div className="mt-10 max-w-3xl space-y-6 text-lg leading-relaxed text-muted md:text-xl">
                  <p>
                    JKOUAM Consultancy was founded by{" "}
                    <span className="text-ink">Josi Kouam</span>, an IT infrastructure and AI
                    engineer based in Toronto. Josi has spent years in enterprise IT support and
                    infrastructure, and has since built production AI systems across
                    retrieval-augmented generation, document understanding, and agentic workflows.
                  </p>
                  <p>
                    He founded JKOUAM Consultancy to help organizations that need serious
                    engineering but don&apos;t have enterprise budgets — non-profits,
                    professional-services firms, public-sector teams, and growing businesses — get
                    access to the same quality of work that larger organizations take for granted.
                  </p>
                </div>
                <Link
                  href="#"
                  className="group mt-12 inline-flex items-center gap-3 border-b border-ink pb-1 text-sm uppercase tracking-wider transition-colors hover:border-sienna hover:text-sienna"
                >
                  See Josi&apos;s personal portfolio
                  <span className="transition-transform group-hover:translate-x-1">→</span>
                </Link>
              </div>
            </div>
          </div>
        </section>

        {/* CTA */}
        <section className="border-b border-rule">
          <div className="mx-auto max-w-7xl px-6 py-24 lg:px-12 lg:py-40">
            <div className="grid gap-12 lg:grid-cols-12 lg:items-end">
              <div className="lg:col-span-3">
                <p className="font-mono text-xs uppercase tracking-[0.2em] text-sienna">
                  — 04 / Talk to us
                </p>
              </div>
              <div className="lg:col-span-9">
                <h2 className="font-display text-4xl font-light leading-[1.05] tracking-tight md:text-5xl lg:text-6xl">
                  Let&apos;s talk.
                </h2>
                <p className="mt-8 max-w-2xl text-lg text-muted md:text-xl">
                  If you have a project in mind, a staffing need, or just a question about whether
                  we&apos;re the right fit — reach out. We respond within two business days.
                </p>
                <Link
                  href="/contact"
                  className="group mt-12 inline-flex items-center gap-4 border-b-2 border-ink pb-2 font-display text-2xl italic transition-colors hover:border-sienna hover:text-sienna md:text-3xl"
                >
                  Contact us
                  <span className="transition-transform group-hover:translate-x-2">→</span>
                </Link>
              </div>
            </div>
          </div>
        </section>
      </main>
      <Footer />
    </>
  );
}

function Belief({ index, title, body }: { index: string; title: string; body: string }) {
  return (
    <div className="flex gap-8">
      <span className="font-display text-xl italic text-sienna">{index}.</span>
      <div className="flex-1 border-t border-bone/20 pt-6">
        <h3 className="font-display text-2xl font-light tracking-tight md:text-3xl">{title}</h3>
        <p className="mt-4 leading-relaxed text-bone/70">{body}</p>
      </div>
    </div>
  );
}
