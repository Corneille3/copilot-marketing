import Link from "next/link";
import { Nav } from "@/components/ui/Nav";
import { Footer } from "@/components/ui/Footer";
import { VideoHero } from "@/components/sections/VideoHero";

export default function Home() {
  return (
    <>
      <Nav overHero />
      <main className="bg-bone text-ink selection:bg-sienna selection:text-bone">
        <VideoHero />

        {/* SERVICES */}
        <section id="services" className="border-b border-rule">
          <div className="mx-auto max-w-7xl px-6 py-24 lg:px-12 lg:py-40">
            <div className="mb-20 grid gap-6 lg:grid-cols-12">
              <div className="lg:col-span-3">
                <p className="font-mono text-xs uppercase tracking-[0.2em] text-sienna">
                  — 01 / What we do
                </p>
              </div>
              <div className="lg:col-span-9">
                <h2 className="font-display text-4xl font-light leading-tight tracking-tight md:text-5xl lg:text-6xl">
                  Two practices.
                  <br />
                  <span className="italic">One firm.</span>
                </h2>
              </div>
            </div>

            <div className="grid gap-px bg-rule lg:grid-cols-2">
              <ServiceCard
                number="01"
                title="AI & Custom Software"
                description="We design and build production-grade applications: retrieval-augmented AI copilots, document understanding pipelines, internal tools, and workflow automations."
                tags={["Accounting", "Legal", "Insurance", "Healthcare", "Public sector", "Education"]}
                tagLabel="Adaptable across"
                href="/services/ai-software"
                status="active"
              />
              <ServiceCard
                number="02"
                title="Bilingual IT Staffing"
                description="We connect organizations with qualified bilingual (EN/FR) IT support technicians across Canada. You interview and hire on your terms."
                tags={["Service desk", "Desktop engineering", "Application support"]}
                tagLabel="Roles we help fill"
                href="/services/it-staffing"
                status="active"
              />
              <ServiceCard
                number="03"
                title="Consulting"
                description="Advisory engagements on AI adoption, compliance-aware AI architecture, and technology modernization."
                href="#"
                status="soon"
              />
              <ServiceCard
                number="04"
                title="Managed Services"
                description="Ongoing operation, monitoring, and support for the systems we build."
                href="#"
                status="soon"
              />
            </div>
          </div>
        </section>

        {/* FEATURED WORK — ComplianceIQ */}
        <section className="border-b border-rule">
          <div className="mx-auto max-w-7xl px-6 py-24 lg:px-12 lg:py-40">
            <div className="mb-16 grid gap-6 lg:grid-cols-12">
              <div className="lg:col-span-3">
                <p className="font-mono text-xs uppercase tracking-[0.2em] text-sienna">
                  — 02 / Featured work
                </p>
              </div>
              <div className="lg:col-span-9">
                <h2 className="font-display text-4xl font-light leading-tight tracking-tight md:text-5xl lg:text-6xl">
                  We don&apos;t just talk
                  <br />
                  about <span className="italic">production AI.</span>
                </h2>
                <p className="mt-8 max-w-2xl text-lg text-muted md:text-xl">
                  See ComplianceIQ — our flagship build — running in production today.
                </p>
              </div>
            </div>

            <div className="grid gap-px bg-rule lg:grid-cols-5">
              <Link
                href="/work/copilot"
                className="group relative col-span-1 block aspect-[16/10] overflow-hidden bg-ink lg:col-span-3 lg:aspect-auto"
              >
                <div className="flex h-full min-h-[320px] items-center justify-center">
                  <div className="text-center">
                    <p className="font-mono text-xs uppercase tracking-[0.2em] text-bone/40">
                      — Product screenshot
                    </p>
                    <p className="mt-3 font-display text-2xl italic text-bone/60">
                      Replace with /public/copilot-screenshot.png
                    </p>
                  </div>
                </div>
                <div className="absolute inset-0 bg-ink/0 transition-colors group-hover:bg-ink/20" />
              </Link>

              <div className="bg-bone p-10 lg:col-span-2 lg:p-14">
                <p className="font-mono text-xs uppercase tracking-[0.2em] text-sienna">
                  ComplianceIQ
                </p>
                <h3 className="mt-6 font-display text-3xl font-light leading-tight tracking-tight md:text-4xl">
                  Compliance research,
                  <br />
                  <span className="italic">grounded.</span>
                </h3>
                <p className="mt-6 text-base leading-relaxed text-muted">
                  A multi-tenant AI research copilot for accounting, legal, and regulated firms.
                  Cited answers from CRA, FINTRAC, OSC, and your own documents — Canadian-hosted,
                  tenant-isolated, audit-ready.
                </p>
                <div className="mt-8 flex flex-col gap-4 sm:flex-row sm:items-center sm:gap-6">
                  <Link
                    href="/work/copilot"
                    className="group inline-flex items-center gap-2 border-b border-ink pb-1 text-sm uppercase tracking-wider transition-colors hover:border-sienna hover:text-sienna"
                  >
                    Read the case study
                    <span className="transition-transform group-hover:translate-x-1">→</span>
                  </Link>
                  <Link
                    href="/contact?intent=demo"
                    className="group inline-flex items-center gap-2 bg-ink px-5 py-3 text-xs uppercase tracking-wider text-bone transition-all hover:bg-sienna"
                  >
                    Book a demo
                    <span className="transition-transform group-hover:translate-x-1">→</span>
                  </Link>
                </div>
              </div>
            </div>
          </div>
        </section>

        {/* WHY */}
        <section className="border-b border-rule bg-ink text-bone">
          <div className="mx-auto max-w-7xl px-6 py-24 lg:px-12 lg:py-40">
            <div className="mb-20 grid gap-6 lg:grid-cols-12">
              <div className="lg:col-span-3">
                <p className="font-mono text-xs uppercase tracking-[0.2em] text-sienna">
                  — 03 / Why work with us
                </p>
              </div>
              <div className="lg:col-span-9">
                <h2 className="font-display text-4xl font-light leading-tight tracking-tight md:text-5xl lg:text-6xl">
                  Small firm.
                  <br />
                  <span className="italic text-sienna">Serious</span> engineering.
                </h2>
              </div>
            </div>

            <div className="grid gap-16 lg:grid-cols-2 lg:gap-x-24 lg:gap-y-20">
              <WhyBlock
                index="i"
                title="Bilingual by design"
                body="Every engagement, deliverable, and line of support is available in English and French — not as an add-on, but as a core capability."
              />
              <WhyBlock
                index="ii"
                title="Canadian-hosted when it matters"
                body="For clients with data-residency, privacy, or regulatory requirements, we default to Canadian infrastructure (AWS ca-central-1)."
              />
              <WhyBlock
                index="iii"
                title="Engineer-led"
                body="Our software work is owned by engineers, not account managers. You talk directly to the person building your solution."
              />
              <WhyBlock
                index="iv"
                title="Practical scale"
                body="We work with non-profits, professional-services firms, growing businesses, and public-sector teams — organizations that need serious engineering without enterprise overhead."
              />
            </div>
          </div>
        </section>

        {/* CTA */}
        <section className="border-b border-rule">
          <div className="mx-auto max-w-7xl px-6 py-24 lg:px-12 lg:py-40">
            <div className="grid gap-12 lg:grid-cols-12 lg:items-end">
              <div className="lg:col-span-3">
                <p className="font-mono text-xs uppercase tracking-[0.2em] text-sienna">
                  — 04 / Start a conversation
                </p>
              </div>
              <div className="lg:col-span-9">
                <h2 className="font-display text-4xl font-light leading-[1.05] tracking-tight md:text-5xl lg:text-7xl">
                  Have a problem
                  <br />
                  <span className="italic">worth solving?</span>
                </h2>
                <p className="mt-8 max-w-2xl text-lg text-muted md:text-xl">
                  Tell us what you&apos;re working on — whether it&apos;s an AI build, a staffing
                  need, or something in between. We&apos;ll reply within two business days with
                  honest feedback on whether we&apos;re the right fit.
                </p>
                <Link
                  href="/contact"
                  className="group mt-12 inline-flex items-center gap-4 border-b-2 border-ink pb-2 font-display text-2xl italic transition-colors hover:border-sienna hover:text-sienna md:text-3xl"
                >
                  Contact us
                  <span className="transition-transform group-hover:translate-x-2">→</span>
                </Link>
              </div>
            </div>
          </div>
        </section>
      </main>
      <Footer />
    </>
  );
}

function ServiceCard({
  number,
  title,
  description,
  tags,
  tagLabel,
  href,
  status,
}: {
  number: string;
  title: string;
  description: string;
  tags?: string[];
  tagLabel?: string;
  href: string;
  status: "active" | "soon";
}) {
  const isActive = status === "active";
  return (
    <Link
      href={isActive ? href : "#"}
      className={`group relative flex flex-col justify-between gap-12 bg-bone p-10 transition-colors lg:p-14 ${
        isActive ? "hover:bg-ink hover:text-bone" : "cursor-default"
      }`}
    >
      <div>
        <div className="mb-10 flex items-center justify-between">
          <span className="font-mono text-xs text-muted group-hover:text-bone/60">— {number}</span>
          {!isActive && (
            <span className="font-mono text-[10px] uppercase tracking-wider text-muted">
              Coming soon
            </span>
          )}
        </div>
        <h3 className="font-display text-3xl font-light leading-tight tracking-tight md:text-4xl">
          {title}
        </h3>
        <p
          className={`mt-6 text-base leading-relaxed ${
            isActive ? "text-muted group-hover:text-bone/80" : "text-muted"
          }`}
        >
          {description}
        </p>
      </div>

      {tags && tagLabel && (
        <div>
          <p className="mb-3 font-mono text-[10px] uppercase tracking-wider text-muted group-hover:text-bone/60">
            {tagLabel}
          </p>
          <div className="flex flex-wrap gap-2">
            {tags.map((tag) => (
              <span
                key={tag}
                className="border border-rule px-3 py-1 text-xs group-hover:border-bone/30"
              >
                {tag}
              </span>
            ))}
          </div>
        </div>
      )}

      {isActive && (
        <div className="mt-auto flex items-center gap-2 text-sm italic">
          <span className="font-display">Learn more</span>
          <span className="transition-transform group-hover:translate-x-1">→</span>
        </div>
      )}
    </Link>
  );
}

function WhyBlock({ index, title, body }: { index: string; title: string; body: string }) {
  return (
    <div className="flex gap-8">
      <span className="font-display text-xl italic text-sienna">{index}.</span>
      <div className="flex-1 border-t border-bone/20 pt-6">
        <h3 className="font-display text-2xl font-light tracking-tight md:text-3xl">{title}</h3>
        <p className="mt-4 leading-relaxed text-bone/70">{body}</p>
      </div>
    </div>
  );
}
