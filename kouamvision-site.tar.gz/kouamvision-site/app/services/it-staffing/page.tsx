import Link from "next/link";
import type { Metadata } from "next";
import { Nav } from "@/components/ui/Nav";
import { Footer } from "@/components/ui/Footer";

export const metadata: Metadata = {
  title: "Bilingual IT Staffing",
  description:
    "We connect organizations with qualified bilingual (English/French) IT support technicians and engineers across Canada. Service desk, desktop engineering, application support.",
};

export default function ITStaffingPage() {
  return (
    <>
      <Nav />
      <main className="min-h-screen pt-20 bg-bone text-ink selection:bg-sienna selection:text-bone">
        {/* HERO */}
        <section className="border-b border-rule">
          <div className="mx-auto max-w-7xl px-6 py-24 lg:px-12 lg:py-40">
            <div className="grid gap-12 lg:grid-cols-12">
              <div className="lg:col-span-3">
                <div className="flex items-center gap-3 text-xs uppercase tracking-[0.2em] text-muted">
                  <span className="inline-block h-px w-8 bg-muted" />
                  <span>Service · 02</span>
                </div>
                <p className="mt-4 font-mono text-xs text-muted">— IT Staffing</p>
              </div>
              <div className="lg:col-span-9">
                <h1 className="font-display text-5xl font-light leading-[1.05] tracking-tight md:text-6xl lg:text-7xl">
                  Bilingual <span className="italic">IT</span>
                  <br />
                  staffing.
                </h1>
                <p className="mt-10 max-w-2xl text-lg text-muted md:text-xl">
                  JKOUAM Consultancy connects organizations with qualified bilingual
                  (English/French) IT support technicians and engineers across Canada.
                </p>
              </div>
            </div>
          </div>
        </section>

        {/* INTRO */}
        <section className="border-b border-rule">
          <div className="mx-auto max-w-7xl px-6 py-24 lg:px-12 lg:py-32">
            <div className="grid gap-12 lg:grid-cols-12">
              <div className="lg:col-span-3">
                <p className="font-mono text-xs uppercase tracking-[0.2em] text-sienna">
                  — 01 / What we do
                </p>
              </div>
              <div className="lg:col-span-9">
                <p className="text-2xl font-light leading-relaxed md:text-3xl">
                  If your team serves customers in both English and French,{" "}
                  <span className="italic">hiring bilingual IT support is harder than it should
                  be.</span>{" "}
                  Most recruiters don&apos;t specialize, most technicians aren&apos;t genuinely
                  bilingual, and qualified candidates are spread thin across a competitive market.
                </p>
                <p className="mt-8 max-w-3xl text-lg leading-relaxed text-muted md:text-xl">
                  JKOUAM Consultancy helps organizations find bilingual IT support talent through
                  our network of technicians, engineers, and support professionals. We introduce
                  qualified candidates to your team; you run your own interview, onboarding, and
                  engagement process.
                </p>
              </div>
            </div>
          </div>
        </section>

        {/* ROLES */}
        <section className="border-b border-rule">
          <div className="mx-auto max-w-7xl px-6 py-24 lg:px-12 lg:py-32">
            <div className="mb-20 grid gap-6 lg:grid-cols-12">
              <div className="lg:col-span-3">
                <p className="font-mono text-xs uppercase tracking-[0.2em] text-sienna">
                  — 02 / Roles
                </p>
              </div>
              <div className="lg:col-span-9">
                <h2 className="font-display text-4xl font-light leading-tight tracking-tight md:text-5xl">
                  Who we can help
                  <br />
                  <span className="italic">you find.</span>
                </h2>
              </div>
            </div>

            <div className="grid gap-px bg-rule lg:grid-cols-3">
              <RoleCard
                index="i"
                title="Service desk & L1 support"
                body="Bilingual technicians for customer-facing IT helpdesks, internal support, and call-centre escalation."
              />
              <RoleCard
                index="ii"
                title="Desktop & infrastructure"
                body="Mid-level bilingual technicians for endpoint management, Active Directory, M365, and network operations."
              />
              <RoleCard
                index="iii"
                title="Application & integration"
                body="Bilingual specialists for line-of-business applications, SaaS administration, and tier-2 application support."
              />
            </div>
          </div>
        </section>

        {/* HOW IT WORKS */}
        <section className="border-b border-rule bg-ink text-bone">
          <div className="mx-auto max-w-7xl px-6 py-24 lg:px-12 lg:py-40">
            <div className="mb-20 grid gap-6 lg:grid-cols-12">
              <div className="lg:col-span-3">
                <p className="font-mono text-xs uppercase tracking-[0.2em] text-sienna">
                  — 03 / Process
                </p>
              </div>
              <div className="lg:col-span-9">
                <h2 className="font-display text-4xl font-light leading-tight tracking-tight md:text-5xl">
                  How it works.
                </h2>
              </div>
            </div>

            <div className="grid gap-12 lg:grid-cols-2 lg:gap-x-24 lg:gap-y-16">
              <Step
                number="01"
                title="You tell us what you need"
                body="Role, location, language requirements, skill level, engagement type (contract, contract-to-hire, permanent)."
              />
              <Step
                number="02"
                title="We source candidates"
                body="From our network. Typically within one to three weeks."
              />
              <Step
                number="03"
                title="We introduce you"
                body="You interview, evaluate, and decide — on your terms."
              />
              <Step
                number="04"
                title="You hire directly"
                body="Or via your preferred employment structure. JKOUAM is paid a referral fee on successful placement."
              />
            </div>
          </div>
        </section>

        {/* WHY BILINGUAL */}
        <section className="border-b border-rule">
          <div className="mx-auto max-w-7xl px-6 py-24 lg:px-12 lg:py-32">
            <div className="grid gap-12 lg:grid-cols-12">
              <div className="lg:col-span-3">
                <p className="font-mono text-xs uppercase tracking-[0.2em] text-sienna">
                  — 04 / Why bilingual
                </p>
              </div>
              <div className="lg:col-span-9">
                <h2 className="font-display text-3xl font-light tracking-tight md:text-4xl">
                  Why bilingual matters.
                </h2>
                <p className="mt-8 max-w-3xl text-lg leading-relaxed text-muted md:text-xl">
                  Nearly 10 million Canadians speak French. For organizations serving customers in
                  Quebec, New Brunswick, Franco-Ontarian and Franco-Manitoban communities, or
                  federally regulated contexts, bilingual IT support isn&apos;t a nice-to-have —{" "}
                  <span className="italic text-ink">it&apos;s a requirement.</span> We help you
                  meet that requirement with people who are genuinely fluent, not just
                  conversational.
                </p>
              </div>
            </div>
          </div>
        </section>

        {/* CTA */}
        <section className="border-b border-rule">
          <div className="mx-auto max-w-7xl px-6 py-24 lg:px-12 lg:py-40">
            <div className="grid gap-12 lg:grid-cols-12 lg:items-end">
              <div className="lg:col-span-3">
                <p className="font-mono text-xs uppercase tracking-[0.2em] text-sienna">
                  — 05 / Next step
                </p>
              </div>
              <div className="lg:col-span-9">
                <h2 className="font-display text-4xl font-light leading-[1.05] tracking-tight md:text-5xl lg:text-6xl">
                  Looking for bilingual
                  <br />
                  <span className="italic">IT talent?</span>
                </h2>
                <p className="mt-8 max-w-2xl text-lg text-muted md:text-xl">
                  Tell us about the role. We&apos;ll reply within two business days with next
                  steps.
                </p>
                <Link
                  href="/contact"
                  className="group mt-12 inline-flex items-center gap-4 border-b-2 border-ink pb-2 font-display text-2xl italic transition-colors hover:border-sienna hover:text-sienna md:text-3xl"
                >
                  Request candidates
                  <span className="transition-transform group-hover:translate-x-2">→</span>
                </Link>
              </div>
            </div>
          </div>
        </section>
      </main>
      <Footer />
    </>
  );
}

function RoleCard({ index, title, body }: { index: string; title: string; body: string }) {
  return (
    <div className="bg-bone p-10 lg:p-12">
      <div className="mb-6 flex items-baseline gap-4">
        <span className="font-display text-lg italic text-sienna">{index}.</span>
        <h3 className="font-display text-xl font-light leading-tight tracking-tight md:text-2xl">
          {title}
        </h3>
      </div>
      <p className="leading-relaxed text-muted">{body}</p>
    </div>
  );
}

function Step({ number, title, body }: { number: string; title: string; body: string }) {
  return (
    <div className="border-t border-bone/20 pt-6">
      <span className="font-mono text-xs text-sienna">— {number}</span>
      <h3 className="mt-4 font-display text-2xl font-light tracking-tight md:text-3xl">{title}</h3>
      <p className="mt-4 leading-relaxed text-bone/70">{body}</p>
    </div>
  );
}
