import Link from "next/link";
import type { Metadata } from "next";
import { Nav } from "@/components/ui/Nav";
import { Footer } from "@/components/ui/Footer";

export const metadata: Metadata = {
  title: "AI & Custom Software",
  description:
    "Production AI applications and custom software for organizations across Canada. Retrieval-augmented copilots, document understanding, internal tools, workflow automation. Canadian-hosted infrastructure.",
};

export default function AISoftwarePage() {
  return (
    <>
      <Nav />
      <main className="min-h-screen pt-20 bg-bone text-ink selection:bg-sienna selection:text-bone">
        {/* HERO */}
        <section className="border-b border-rule">
          <div className="mx-auto max-w-7xl px-6 py-24 lg:px-12 lg:py-40">
            <div className="grid gap-12 lg:grid-cols-12">
              <div className="lg:col-span-3">
                <div className="flex items-center gap-3 text-xs uppercase tracking-[0.2em] text-muted">
                  <span className="inline-block h-px w-8 bg-muted" />
                  <span>Service · 01</span>
                </div>
                <p className="mt-4 font-mono text-xs text-muted">— AI &amp; Software</p>
              </div>
              <div className="lg:col-span-9">
                <h1 className="font-display text-5xl font-light leading-[1.05] tracking-tight md:text-6xl lg:text-7xl">
                  AI &amp; <span className="italic">custom</span>
                  <br />
                  software.
                </h1>
                <p className="mt-10 max-w-2xl text-lg text-muted md:text-xl">
                  We build production AI applications and custom software for organizations that
                  need serious engineering without enterprise overhead.
                </p>
              </div>
            </div>
          </div>
        </section>

        {/* FLAGSHIP BUILD */}
        <section className="border-b border-rule bg-ink text-bone">
          <div className="mx-auto max-w-7xl px-6 py-24 lg:px-12 lg:py-32">
            <div className="grid gap-12 lg:grid-cols-12 lg:items-center">
              <div className="lg:col-span-3">
                <p className="font-mono text-xs uppercase tracking-[0.2em] text-sienna">
                  — Flagship build
                </p>
                <p className="mt-4 font-mono text-xs text-bone/50">In production · 2026</p>
              </div>
              <div className="lg:col-span-9">
                <h2 className="font-display text-3xl font-light leading-tight tracking-tight md:text-4xl lg:text-5xl">
                  ComplianceIQ —
                  <br />
                  <span className="italic text-sienna">our flagship build.</span>
                </h2>
                <p className="mt-8 max-w-3xl text-lg leading-relaxed text-bone/80 md:text-xl">
                  A multi-tenant AI compliance research copilot for accounting, legal, and
                  regulated firms. Cited answers from CRA, FINTRAC, OSC, and your own documents.
                  Hybrid retrieval, authority-aware reranking, audit-ready, Canadian-hosted.
                </p>
                <div className="mt-10 flex flex-wrap items-center gap-6">
                  <Link
                    href="/work/copilot"
                    className="group inline-flex items-center gap-3 bg-bone px-7 py-4 text-sm uppercase tracking-wider text-ink transition-all hover:bg-sienna hover:text-bone"
                  >
                    See the case study
                    <span className="transition-transform group-hover:translate-x-1">→</span>
                  </Link>
                  <Link
                    href="/contact?intent=demo"
                    className="group inline-flex items-center gap-2 border-b border-bone pb-1 text-sm uppercase tracking-wider text-bone transition-colors hover:border-sienna hover:text-sienna"
                  >
                    Book a demo →
                  </Link>
                </div>
              </div>
            </div>
          </div>
        </section>

        {/* WHAT WE BUILD */}
        <section className="border-b border-rule">
          <div className="mx-auto max-w-7xl px-6 py-24 lg:px-12 lg:py-40">
            <div className="mb-20 grid gap-6 lg:grid-cols-12">
              <div className="lg:col-span-3">
                <p className="font-mono text-xs uppercase tracking-[0.2em] text-sienna">
                  — 01 / What we build
                </p>
              </div>
              <div className="lg:col-span-9">
                <h2 className="font-display text-4xl font-light leading-tight tracking-tight md:text-5xl">
                  Four kinds of work,
                  <br />
                  <span className="italic">one philosophy.</span>
                </h2>
              </div>
            </div>

            <div className="grid gap-px bg-rule lg:grid-cols-2">
              <CapabilityCard
                index="i"
                title="AI copilots & retrieval"
                body="Retrieval-augmented generation (RAG) platforms that answer questions grounded in your own documents — with citations, evidence boundaries, and audit trails. Built for industries where answers need to be defensible."
              />
              <CapabilityCard
                index="ii"
                title="Document understanding"
                body="Ingestion, classification, and extraction from PDFs, Word, Excel, PowerPoint, email, and scanned images. OCR fallback, metadata normalization, and tenant isolation built in."
              />
              <CapabilityCard
                index="iii"
                title="Internal tools & automation"
                body="The spreadsheet that should be an application. The manual process that could be a workflow. The form that should trigger an alert. The unglamorous software that saves teams hours every week."
              />
              <CapabilityCard
                index="iv"
                title="AI-powered applications"
                body="From image generators to agentic assistants — if there's a practical AI use case, we can design and ship it."
              />
            </div>
          </div>
        </section>

        {/* HOW WE WORK */}
        <section className="border-b border-rule bg-ink text-bone">
          <div className="mx-auto max-w-7xl px-6 py-24 lg:px-12 lg:py-40">
            <div className="mb-20 grid gap-6 lg:grid-cols-12">
              <div className="lg:col-span-3">
                <p className="font-mono text-xs uppercase tracking-[0.2em] text-sienna">
                  — 02 / How we work
                </p>
              </div>
              <div className="lg:col-span-9">
                <h2 className="font-display text-4xl font-light leading-tight tracking-tight md:text-5xl">
                  Three phases.
                  <br />
                  <span className="italic">No surprises.</span>
                </h2>
              </div>
            </div>

            <div className="grid gap-12 lg:grid-cols-3">
              <PhaseBlock
                number="01"
                title="Discovery"
                duration="1–2 weeks"
                body="We map your problem, constraints, and success criteria. You get a written scope, fixed-price estimate, and clear timeline — or an honest 'we're not the right fit.'"
              />
              <PhaseBlock
                number="02"
                title="Build"
                duration="4–12 weeks typical"
                body="Iterative delivery with working software at each checkpoint. No six-month waterfalls. You see progress weekly."
              />
              <PhaseBlock
                number="03"
                title="Launch & handoff"
                duration="Plus optional support"
                body="Production deployment, documentation, and optional ongoing support. Code is yours, infrastructure is yours, no vendor lock-in."
              />
            </div>
          </div>
        </section>

        {/* STACK */}
        <section className="border-b border-rule">
          <div className="mx-auto max-w-7xl px-6 py-24 lg:px-12 lg:py-32">
            <div className="grid gap-12 lg:grid-cols-12">
              <div className="lg:col-span-3">
                <p className="font-mono text-xs uppercase tracking-[0.2em] text-sienna">
                  — 03 / Stack
                </p>
              </div>
              <div className="lg:col-span-9">
                <h2 className="font-display text-3xl font-light tracking-tight md:text-4xl">
                  What we build with.
                </h2>
                <div className="mt-10 grid gap-8 md:grid-cols-2 lg:grid-cols-3">
                  <StackGroup
                    label="Backend"
                    items={["Python", "FastAPI", "PostgreSQL + pgvector"]}
                  />
                  <StackGroup
                    label="Frontend"
                    items={["TypeScript", "Next.js", "React"]}
                  />
                  <StackGroup
                    label="AI"
                    items={["OpenAI", "Open-source models", "RAG, embeddings"]}
                  />
                  <StackGroup
                    label="Infrastructure"
                    items={["AWS (ECS, RDS, S3)", "Terraform", "Cognito"]}
                  />
                  <StackGroup
                    label="Data residency"
                    items={["Canadian by default", "AWS ca-central-1"]}
                  />
                  <StackGroup label="Languages" items={["English", "French"]} />
                </div>
              </div>
            </div>
          </div>
        </section>

        {/* INDUSTRIES */}
        <section className="border-b border-rule">
          <div className="mx-auto max-w-7xl px-6 py-24 lg:px-12 lg:py-32">
            <div className="grid gap-12 lg:grid-cols-12">
              <div className="lg:col-span-3">
                <p className="font-mono text-xs uppercase tracking-[0.2em] text-sienna">
                  — 04 / Industries
                </p>
              </div>
              <div className="lg:col-span-9">
                <h2 className="font-display text-3xl font-light tracking-tight md:text-4xl">
                  Where our work fits.
                </h2>
                <p className="mt-6 max-w-3xl text-lg text-muted">
                  Our AI platform is adaptable across regulated and document-heavy industries — any
                  environment where correctness and traceability matter.
                </p>
                <div className="mt-10 flex flex-wrap gap-3">
                  {[
                    "Accounting & professional services",
                    "Legal & compliance",
                    "Non-profits & community organizations",
                    "Education & early childhood",
                    "Public sector",
                    "Franco-Canadian organizations",
                    "Insurance",
                    "Healthcare compliance",
                  ].map((tag) => (
                    <span key={tag} className="border border-rule px-4 py-2 text-sm">
                      {tag}
                    </span>
                  ))}
                </div>
              </div>
            </div>
          </div>
        </section>

        {/* CTA */}
        <section className="border-b border-rule">
          <div className="mx-auto max-w-7xl px-6 py-24 lg:px-12 lg:py-40">
            <div className="grid gap-12 lg:grid-cols-12 lg:items-end">
              <div className="lg:col-span-3">
                <p className="font-mono text-xs uppercase tracking-[0.2em] text-sienna">
                  — 05 / Next step
                </p>
              </div>
              <div className="lg:col-span-9">
                <h2 className="font-display text-4xl font-light leading-[1.05] tracking-tight md:text-5xl lg:text-6xl">
                  Ready to scope
                  <br />
                  <span className="italic">a project?</span>
                </h2>
                <p className="mt-8 max-w-2xl text-lg text-muted md:text-xl">
                  Tell us what you&apos;re working on. We&apos;ll reply within two business days
                  with honest feedback on whether — and how — we can help.
                </p>
                <Link
                  href="/contact"
                  className="group mt-12 inline-flex items-center gap-4 border-b-2 border-ink pb-2 font-display text-2xl italic transition-colors hover:border-sienna hover:text-sienna md:text-3xl"
                >
                  Start a project
                  <span className="transition-transform group-hover:translate-x-2">→</span>
                </Link>
              </div>
            </div>
          </div>
        </section>
      </main>
      <Footer />
    </>
  );
}

function CapabilityCard({ index, title, body }: { index: string; title: string; body: string }) {
  return (
    <div className="bg-bone p-10 lg:p-14">
      <div className="mb-8 flex items-baseline gap-4">
        <span className="font-display text-xl italic text-sienna">{index}.</span>
        <h3 className="font-display text-2xl font-light leading-tight tracking-tight md:text-3xl">
          {title}
        </h3>
      </div>
      <p className="leading-relaxed text-muted">{body}</p>
    </div>
  );
}

function PhaseBlock({
  number,
  title,
  duration,
  body,
}: {
  number: string;
  title: string;
  duration: string;
  body: string;
}) {
  return (
    <div className="border-t border-bone/20 pt-6">
      <div className="mb-6 flex items-center justify-between">
        <span className="font-mono text-xs text-bone/60">— {number}</span>
        <span className="font-mono text-[10px] uppercase tracking-wider text-bone/50">
          {duration}
        </span>
      </div>
      <h3 className="font-display text-2xl font-light tracking-tight md:text-3xl">{title}</h3>
      <p className="mt-4 leading-relaxed text-bone/70">{body}</p>
    </div>
  );
}

function StackGroup({ label, items }: { label: string; items: string[] }) {
  return (
    <div>
      <p className="mb-3 font-mono text-[10px] uppercase tracking-wider text-muted">{label}</p>
      <ul className="space-y-1.5 text-base">
        {items.map((item) => (
          <li key={item}>{item}</li>
        ))}
      </ul>
    </div>
  );
}
