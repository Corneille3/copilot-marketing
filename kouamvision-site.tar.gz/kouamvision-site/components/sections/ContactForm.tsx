"use client";

import { useEffect, useState } from "react";
import { useSearchParams } from "next/navigation";

type Intent = "demo" | "project" | "staffing" | "general";

const INTENT_META: Record<
  Intent,
  { label: string; eyebrow: string; description: string; submitLabel: string }
> = {
  demo: {
    label: "Book a ComplianceIQ demo",
    eyebrow: "Demo",
    description:
      "See ComplianceIQ in action. We'll walk through your real questions on real documents in a 30-minute live session — and tell you honestly whether it fits your firm's workflow.",
    submitLabel: "Request demo",
  },
  project: {
    label: "Start a software project",
    eyebrow: "Build",
    description:
      "You have an AI application, internal tool, or custom software project in mind — or you're not sure yet, and want to talk it through.",
    submitLabel: "Send project inquiry",
  },
  staffing: {
    label: "Request bilingual IT candidates",
    eyebrow: "Staff",
    description:
      "You need bilingual (EN/FR) IT support technicians or engineers and want to see qualified candidates from our network.",
    submitLabel: "Send staffing request",
  },
  general: {
    label: "General inquiry",
    eyebrow: "Hello",
    description: "Partnership, press, general question, or something else.",
    submitLabel: "Send message",
  },
};

const VALID_INTENTS: Intent[] = ["demo", "project", "staffing", "general"];

export function ContactForm() {
  const searchParams = useSearchParams();
  const [intent, setIntent] = useState<Intent>("project");
  const [status, setStatus] = useState<"idle" | "submitting" | "success" | "error">("idle");
  const [errorMessage, setErrorMessage] = useState<string>("");

  // Pick up ?intent=demo from URL on mount
  useEffect(() => {
    const param = searchParams.get("intent");
    if (param && (VALID_INTENTS as string[]).includes(param)) {
      setIntent(param as Intent);
    }
  }, [searchParams]);

  async function handleSubmit(e: React.FormEvent<HTMLFormElement>) {
    e.preventDefault();
    setStatus("submitting");
    setErrorMessage("");

    const formData = new FormData(e.currentTarget);
    const payload: Record<string, string> = { intent };
    formData.forEach((value, key) => {
      if (typeof value === "string") payload[key] = value;
    });

    try {
      const res = await fetch("/api/contact", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(payload),
      });

      if (!res.ok) {
        const data = await res.json().catch(() => ({}));
        throw new Error(data.error || "Submission failed");
      }

      setStatus("success");
      e.currentTarget.reset();
    } catch (err) {
      setStatus("error");
      setErrorMessage(err instanceof Error ? err.message : "Something went wrong");
    }
  }

  if (status === "success") {
    return (
      <div className="border border-rule bg-bone p-12 text-center">
        <p className="font-mono text-xs uppercase tracking-[0.2em] text-sienna">— Received</p>
        <h2 className="mt-6 font-display text-3xl font-light italic md:text-4xl">Thank you.</h2>
        <p className="mt-6 text-lg text-muted">
          {intent === "demo"
            ? "Your demo request has been received. We'll reach out within two business days to schedule a time."
            : "Your message has been received. We'll reply within two business days."}
        </p>
        <button
          onClick={() => setStatus("idle")}
          className="mt-8 border-b border-ink pb-1 text-sm uppercase tracking-wider transition-colors hover:border-sienna hover:text-sienna"
        >
          Send another message
        </button>
      </div>
    );
  }

  return (
    <div>
      {/* Intent picker */}
      <div className="mb-12">
        <p className="mb-4 font-mono text-xs uppercase tracking-[0.2em] text-muted">
          — How can we help?
        </p>
        <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-4">
          {(Object.keys(INTENT_META) as Intent[]).map((key) => {
            const meta = INTENT_META[key];
            const active = intent === key;
            return (
              <button
                key={key}
                type="button"
                onClick={() => setIntent(key)}
                className={`group border p-5 text-left transition-all ${
                  active
                    ? "border-ink bg-ink text-bone"
                    : "border-rule bg-bone hover:border-ink"
                }`}
              >
                <p
                  className={`font-mono text-xs uppercase tracking-wider ${
                    active ? "text-sienna" : "text-muted"
                  }`}
                >
                  {meta.eyebrow}
                </p>
                <p className="mt-2 font-display text-base leading-tight">{meta.label}</p>
              </button>
            );
          })}
        </div>
      </div>

      {/* Form */}
      <form onSubmit={handleSubmit} className="space-y-8">
        <p className="text-base text-muted">{INTENT_META[intent].description}</p>

        {/* Honeypot — hidden from humans, bots fill it */}
        <input
          type="text"
          name="website"
          tabIndex={-1}
          autoComplete="off"
          className="absolute left-[-9999px] h-0 w-0 opacity-0"
          aria-hidden="true"
        />

        {/* Common fields */}
        <div className="grid gap-6 md:grid-cols-2">
          <Field label="Name" name="name" required />
          <Field label="Email" name="email" type="email" required />
        </div>
        <Field label="Organization" name="organization" />

        {/* Demo-specific fields */}
        {intent === "demo" && (
          <>
            <div className="grid gap-6 md:grid-cols-2">
              <Field label="Your role" name="role" required />
              <SelectField
                label="Firm size"
                name="firm_size"
                required
                options={["1–5 staff", "6–25 staff", "26–100 staff", "100+ staff"]}
              />
            </div>
            <SelectField
              label="Primary use case"
              name="use_case"
              required
              options={[
                "Tax research",
                "Audit / assurance",
                "AML / FINTRAC",
                "Securities / compliance",
                "General compliance research",
                "Other",
              ]}
            />
            <SelectField
              label="Preferred time window"
              name="preferred_time"
              options={[
                "Mornings (ET)",
                "Afternoons (ET)",
                "Flexible",
              ]}
            />
            <Field
              label="Anything specific you'd like us to demo?"
              name="demo_notes"
              type="textarea"
            />
          </>
        )}

        {/* Project-specific fields */}
        {intent === "project" && (
          <>
            <Field
              label="What are you trying to build?"
              name="project_description"
              type="textarea"
              required
            />
            <div className="grid gap-6 md:grid-cols-2">
              <SelectField
                label="Rough budget range"
                name="budget"
                required
                options={[
                  "Under $10k",
                  "$10k–$25k",
                  "$25k–$75k",
                  "$75k–$200k",
                  "$200k+",
                  "Not sure yet",
                ]}
              />
              <SelectField
                label="Target timeline"
                name="timeline"
                options={["ASAP", "Within 1 month", "1–3 months", "3–6 months", "Flexible"]}
              />
            </div>
          </>
        )}

        {/* Staffing-specific fields */}
        {intent === "staffing" && (
          <>
            <Field label="Role(s) needed" name="role" required />
            <div className="grid gap-6 md:grid-cols-2">
              <Field label="Location (city / remote / hybrid)" name="location" required />
              <SelectField
                label="Engagement type"
                name="engagement"
                required
                options={["Contract", "Contract-to-hire", "Permanent"]}
              />
            </div>
            <Field label="Target start date" name="start_date" />
            <Field label="Anything else we should know?" name="notes" type="textarea" />
          </>
        )}

        {/* General */}
        {intent === "general" && (
          <Field label="Message" name="message" type="textarea" required />
        )}

        <Field label="How did you hear about us? (optional)" name="referral" />

        <div className="flex flex-col items-start gap-4 border-t border-rule pt-8">
          {status === "error" && (
            <p className="text-sm text-sienna">
              {errorMessage || "Something went wrong. Please try again."}
            </p>
          )}
          <button
            type="submit"
            disabled={status === "submitting"}
            className="group inline-flex items-center gap-3 bg-ink px-7 py-4 text-sm uppercase tracking-wider text-bone transition-all hover:bg-sienna disabled:opacity-50"
          >
            {status === "submitting" ? "Sending…" : INTENT_META[intent].submitLabel}
            <span className="transition-transform group-hover:translate-x-1">→</span>
          </button>
          <p className="text-xs text-muted">We&apos;ll reply within two business days.</p>
        </div>
      </form>
    </div>
  );
}

function Field({
  label,
  name,
  type = "text",
  required = false,
}: {
  label: string;
  name: string;
  type?: "text" | "email" | "textarea";
  required?: boolean;
}) {
  const baseClass =
    "w-full border border-rule bg-bone px-4 py-3 text-base text-ink placeholder:text-muted/60 focus:border-ink focus:outline-none";
  return (
    <label className="block">
      <span className="mb-2 block font-mono text-xs uppercase tracking-wider text-muted">
        {label} {required && <span className="text-sienna">*</span>}
      </span>
      {type === "textarea" ? (
        <textarea name={name} required={required} rows={5} className={baseClass} />
      ) : (
        <input type={type} name={name} required={required} className={baseClass} />
      )}
    </label>
  );
}

function SelectField({
  label,
  name,
  options,
  required = false,
}: {
  label: string;
  name: string;
  options: string[];
  required?: boolean;
}) {
  return (
    <label className="block">
      <span className="mb-2 block font-mono text-xs uppercase tracking-wider text-muted">
        {label} {required && <span className="text-sienna">*</span>}
      </span>
      <select
        name={name}
        required={required}
        defaultValue=""
        className="w-full appearance-none border border-rule bg-bone px-4 py-3 text-base text-ink focus:border-ink focus:outline-none"
      >
        <option value="" disabled>
          Select…
        </option>
        {options.map((opt) => (
          <option key={opt} value={opt}>
            {opt}
          </option>
        ))}
      </select>
    </label>
  );
}
