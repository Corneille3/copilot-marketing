"use client";

import Link from "next/link";
import { useEffect, useRef, useState } from "react";

export function VideoHero() {
  const videoRef = useRef<HTMLVideoElement>(null);
  const [reduceMotion, setReduceMotion] = useState(false);

  useEffect(() => {
    const mq = window.matchMedia("(prefers-reduced-motion: reduce)");
    setReduceMotion(mq.matches);
    const handler = (e: MediaQueryListEvent) => setReduceMotion(e.matches);
    mq.addEventListener("change", handler);
    return () => mq.removeEventListener("change", handler);
  }, []);

  useEffect(() => {
    if (videoRef.current && !reduceMotion) {
      videoRef.current.play().catch(() => {
        // Autoplay can be blocked — silent fallback to poster image
      });
    }
  }, [reduceMotion]);

  return (
    <section className="relative h-screen min-h-[640px] w-full overflow-hidden bg-ink text-bone">
      {/* Video background */}
      {!reduceMotion && (
        <video
          ref={videoRef}
          className="absolute inset-0 h-full w-full object-cover"
          autoPlay
          loop
          muted
          playsInline
          preload="metadata"
          poster="/hero-poster.jpg"
          aria-hidden="true"
        >
          <source src="/hero-bg.mp4" type="video/mp4" />
          <source src="/hero-bg.webm" type="video/webm" />
        </video>
      )}

      {/* Static poster fallback for reduced motion */}
      {reduceMotion && (
        <div
          className="absolute inset-0 h-full w-full bg-cover bg-center"
          style={{ backgroundImage: "url(/hero-poster.jpg)" }}
          aria-hidden="true"
        />
      )}

      {/* Dark overlay — gradient bottom to maintain contrast on white text */}
      <div
        className="absolute inset-0 bg-gradient-to-b from-ink/70 via-ink/55 to-ink/85"
        aria-hidden="true"
      />

      {/* Subtle grain for editorial feel */}
      <div
        className="pointer-events-none absolute inset-0 opacity-[0.08] mix-blend-overlay"
        style={{
          backgroundImage:
            "url(\"data:image/svg+xml,%3Csvg viewBox='0 0 200 200' xmlns='http://www.w3.org/2000/svg'%3E%3Cfilter id='n'%3E%3CfeTurbulence type='fractalNoise' baseFrequency='0.85' numOctaves='3'/%3E%3C/filter%3E%3Crect width='100%25' height='100%25' filter='url(%23n)' opacity='0.6'/%3E%3C/svg%3E\")",
        }}
        aria-hidden="true"
      />

      {/* Content */}
      <div className="relative z-10 flex h-full items-center">
        <div className="mx-auto w-full max-w-7xl px-6 lg:px-12">
          <div className="grid gap-12 lg:grid-cols-12">
            <div className="lg:col-span-3">
              <div className="flex items-center gap-3 text-xs uppercase tracking-[0.2em] text-bone/70 opacity-0 animate-fade-up">
                <span className="inline-block h-px w-8 bg-bone/50" />
                <span>Toronto · Canada</span>
              </div>
              <p className="mt-4 font-mono text-xs text-bone/60 opacity-0 animate-fade-up [animation-delay:100ms]">
                Est. 2026
              </p>
            </div>

            <div className="lg:col-span-9">
              <h1 className="font-display text-[2.75rem] font-light leading-[1.02] tracking-[-0.02em] text-bone opacity-0 animate-fade-up [animation-delay:200ms] md:text-6xl lg:text-[5.5rem]">
                AI, custom software,
                <br />
                and <span className="italic text-sienna">bilingual</span> IT support
                <br />— from one Canadian firm.
              </h1>

              <p className="mt-10 max-w-2xl text-lg leading-relaxed text-bone/80 opacity-0 animate-fade-up [animation-delay:400ms] md:text-xl">
                <span className="font-medium text-bone">JKOUAM Consultancy Inc.</span> is a
                Toronto-based technology firm serving organizations across Canada. We build
                production AI and custom software, and we help organizations find bilingual IT
                support technicians for teams that serve English and French customers.
              </p>

              <div className="mt-12 flex flex-wrap items-center gap-6 opacity-0 animate-fade-up [animation-delay:600ms]">
                <Link
                  href="#services"
                  className="group inline-flex items-center gap-3 bg-bone px-7 py-4 text-sm uppercase tracking-wider text-ink transition-all hover:bg-sienna hover:text-bone"
                >
                  Explore our services
                  <span className="transition-transform group-hover:translate-x-1">→</span>
                </Link>
                <Link
                  href="/contact"
                  className="group inline-flex items-center gap-2 border-b border-bone pb-1 text-sm uppercase tracking-wider text-bone transition-colors hover:border-sienna hover:text-sienna"
                >
                  Start a conversation
                </Link>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Scroll cue */}
      <a
        href="#services"
        className="group absolute bottom-8 left-1/2 z-10 -translate-x-1/2 text-bone/60 opacity-0 animate-fade-up [animation-delay:900ms] hover:text-bone"
        aria-label="Scroll to services"
      >
        <div className="flex flex-col items-center gap-2">
          <span className="font-mono text-[10px] uppercase tracking-[0.2em]">Scroll</span>
          <div className="h-10 w-px animate-pulse bg-current" />
        </div>
      </a>

      {/* Corner mark */}
      <div className="pointer-events-none absolute bottom-8 right-8 z-10 hidden font-mono text-xs text-bone/50 lg:block">
        [ kouamvision.com ]
      </div>
    </section>
  );
}
