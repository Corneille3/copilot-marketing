export function SectionEyebrow({ number, label }: { number: string; label: string }) {
  return (
    <p className="font-mono text-xs uppercase tracking-[0.2em] text-sienna">
      — {number} / {label}
    </p>
  );
}

export function PageEyebrow({ label }: { label: string }) {
  return (
    <div className="flex items-center gap-3 text-xs uppercase tracking-[0.2em] text-muted">
      <span className="inline-block h-px w-8 bg-muted" />
      <span>{label}</span>
    </div>
  );
}
