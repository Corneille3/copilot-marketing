import Link from "next/link";

export function Footer() {
  return (
    <footer className="bg-bone">
      <div className="mx-auto max-w-7xl px-6 py-16 lg:px-12">
        <div className="grid gap-12 lg:grid-cols-12">
          <div className="lg:col-span-4">
            <p className="font-display text-2xl">
              <span className="italic">JKOUAM</span> Consultancy Inc.
            </p>
            <p className="mt-3 text-sm text-muted">
              Toronto, Ontario · Serving clients across Canada
            </p>
          </div>
          <div className="lg:col-span-2">
            <p className="mb-4 font-mono text-xs uppercase tracking-wider text-muted">Services</p>
            <ul className="space-y-2 text-sm">
              <li>
                <Link href="/services/ai-software" className="hover:text-sienna">
                  AI &amp; Software
                </Link>
              </li>
              <li>
                <Link href="/services/it-staffing" className="hover:text-sienna">
                  IT Staffing
                </Link>
              </li>
              <li>
                <span className="text-muted">Consulting (soon)</span>
              </li>
              <li>
                <span className="text-muted">Managed Services (soon)</span>
              </li>
            </ul>
          </div>
          <div className="lg:col-span-2">
            <p className="mb-4 font-mono text-xs uppercase tracking-wider text-muted">Firm</p>
            <ul className="space-y-2 text-sm">
              <li>
                <Link href="/about" className="hover:text-sienna">
                  About
                </Link>
              </li>
              <li>
                <Link href="/contact" className="hover:text-sienna">
                  Contact
                </Link>
              </li>
            </ul>
          </div>
          <div className="lg:col-span-2">
            <p className="mb-4 font-mono text-xs uppercase tracking-wider text-muted">Work</p>
            <ul className="space-y-2 text-sm">
              <li>
                <Link href="/work/copilot" className="hover:text-sienna">
                  ComplianceIQ
                </Link>
              </li>
              <li>
                <Link href="/contact?intent=demo" className="hover:text-sienna">
                  Book a demo
                </Link>
              </li>
            </ul>
          </div>
          <div className="lg:col-span-2">
            <p className="mb-4 font-mono text-xs uppercase tracking-wider text-muted">Founder</p>
            <p className="text-sm text-muted">
              See Josi&apos;s{" "}
              <Link href="#" className="underline underline-offset-4 hover:text-sienna">
                personal portfolio →
              </Link>
            </p>
          </div>
        </div>
        <div className="mt-16 flex flex-col justify-between gap-4 border-t border-rule pt-8 text-xs text-muted md:flex-row">
          <p>© {new Date().getFullYear()} JKOUAM Consultancy Inc. All rights reserved.</p>
          <p className="font-mono">kouamvision.com</p>
        </div>
      </div>
    </footer>
  );
}
