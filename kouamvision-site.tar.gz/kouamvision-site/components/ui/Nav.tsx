"use client";

import Link from "next/link";
import { useEffect, useState } from "react";

export function Nav({ overHero = false }: { overHero?: boolean }) {
  const [scrolled, setScrolled] = useState(false);

  useEffect(() => {
    if (!overHero) {
      setScrolled(true);
      return;
    }
    const onScroll = () => setScrolled(window.scrollY > 80);
    onScroll();
    window.addEventListener("scroll", onScroll, { passive: true });
    return () => window.removeEventListener("scroll", onScroll);
  }, [overHero]);

  return (
    <nav
      className={`fixed inset-x-0 top-0 z-50 transition-all duration-300 ${
        scrolled
          ? "border-b border-rule bg-bone/85 backdrop-blur-md"
          : "border-b border-transparent bg-transparent"
      }`}
    >
      <div className="mx-auto flex max-w-7xl items-center justify-between px-6 py-5 lg:px-12">
        <Link
          href="/"
          className={`font-display text-xl tracking-tight transition-colors ${
            scrolled ? "text-ink" : "text-bone"
          }`}
        >
          <span className="italic">JKOUAM</span> Consultancy
        </Link>
        <div
          className={`hidden items-center gap-10 text-sm transition-colors md:flex ${
            scrolled ? "text-muted" : "text-bone/85"
          }`}
        >
          <Link
            href="/services/ai-software"
            className={scrolled ? "hover:text-ink" : "hover:text-bone"}
          >
            AI &amp; Software
          </Link>
          <Link
            href="/services/it-staffing"
            className={scrolled ? "hover:text-ink" : "hover:text-bone"}
          >
            Staffing
          </Link>
          <Link
            href="/work/copilot"
            className={scrolled ? "hover:text-ink" : "hover:text-bone"}
          >
            Work
          </Link>
          <Link href="/about" className={scrolled ? "hover:text-ink" : "hover:text-bone"}>
            About
          </Link>
          <Link
            href="/contact"
            className={`px-5 py-2 transition-all ${
              scrolled
                ? "border border-ink text-ink hover:bg-ink hover:text-bone"
                : "border border-bone text-bone hover:bg-bone hover:text-ink"
            }`}
          >
            Contact
          </Link>
        </div>
      </div>
    </nav>
  );
}
