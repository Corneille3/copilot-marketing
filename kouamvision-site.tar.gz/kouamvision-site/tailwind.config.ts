import type { Config } from "tailwindcss";

const config: Config = {
  content: ["./app/**/*.{ts,tsx}", "./components/**/*.{ts,tsx}"],
  theme: {
    extend: {
      colors: {
        bone: "var(--bone)",
        ink: "var(--ink)",
        sienna: "var(--sienna)",
        muted: "var(--muted)",
        rule: "var(--rule)",
      },
      fontFamily: {
        display: ["var(--font-display)", "Georgia", "serif"],
        body: ["var(--font-body)", "system-ui", "sans-serif"],
        mono: ["var(--font-mono)", "ui-monospace", "monospace"],
      },
      maxWidth: {
        "7xl": "84rem",
      },
    },
  },
  plugins: [],
};

export default config;
