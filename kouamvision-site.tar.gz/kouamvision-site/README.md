# JKOUAM Consultancy — Firm marketing site

Production-ready Next.js 15 site for `kouamvision.com`.

## Stack

- Next.js 15 (App Router) · React 19 · TypeScript 5
- Tailwind CSS 3
- Resend for contact form delivery
- Fonts: Fraunces (display) + IBM Plex Sans (body) + IBM Plex Mono (meta), all via `next/font`

## Setup

```bash
npm install
cp .env.example .env.local
# Fill in RESEND_API_KEY, CONTACT_TO_EMAIL, CONTACT_FROM_EMAIL
npm run dev
```

Open http://localhost:3000.

## Required environment variables

| Variable                | What it does                                       |
|-------------------------|----------------------------------------------------|
| `RESEND_API_KEY`        | Resend API key (https://resend.com — free tier: 3,000 emails/mo) |
| `CONTACT_TO_EMAIL`      | Where contact form submissions are delivered       |
| `CONTACT_FROM_EMAIL`    | Verified sender domain in Resend (e.g. noreply@kouamvision.com) |
| `NEXT_PUBLIC_SITE_URL`  | Canonical site URL — used for metadata & sitemap   |

**Resend domain verification:** in the Resend dashboard, add `kouamvision.com` and add the DNS records they generate (SPF, DKIM). Without this, emails will go to spam or be rejected.

## Hero video

The homepage uses a full-viewport video background. See `public/README.md` for the three required files (`hero-bg.mp4`, `hero-bg.webm`, `hero-poster.jpg`) and ffmpeg encoding commands.

The site renders fine without them — visitors just see the gradient overlay over the deep ink background until you drop the video files in.

## Project structure

```
app/
  layout.tsx              ← root layout, fonts, JSON-LD Organization schema
  globals.css             ← Tailwind + CSS vars (palette) + fade-up animation
  page.tsx                ← Homepage (video hero + services + featured work + why + CTA)
  about/page.tsx
  contact/page.tsx        ← Reads ?intent=demo from URL to pre-select demo intent
  services/
    ai-software/page.tsx  ← Includes "Flagship build" section linking to /work/copilot
    it-staffing/page.tsx
  work/
    copilot/page.tsx      ← ComplianceIQ product / case study page
  api/
    contact/route.ts      ← Resend integration, validation, rate limit, honeypot, demo intent
  sitemap.ts              ← /sitemap.xml
  robots.ts               ← /robots.txt
components/
  ui/
    Nav.tsx               ← Scroll-aware: transparent over hero, solid after
    Footer.tsx
    Eyebrow.tsx
  sections/
    VideoHero.tsx         ← Full-viewport video + overlay + grain + scroll cue
    ContactForm.tsx       ← Three-intent form (project / staffing / general)
public/
  README.md               ← Asset requirements (video + posters)
```

## Design system

Defined as CSS variables in `app/globals.css`:

| Variable      | Value      | Use                          |
|---------------|------------|------------------------------|
| `--bone`      | `#F5F1E8`  | Background — warm cream      |
| `--ink`       | `#1C1B17`  | Primary text — deep graphite |
| `--sienna`    | `#B84A2E`  | Single accent — burnt orange |
| `--muted`     | `#6B665C`  | Secondary text               |
| `--rule`      | `#D9D2C1`  | Hairline dividers            |

Fonts via `next/font` (no external CSS, no FOUT):

- **Display:** Fraunces, variable optical-size axis tuned for large headlines
- **Body:** IBM Plex Sans (300/400/500/600)
- **Mono:** IBM Plex Mono (400/500) — used for eyebrows and meta text

## Contact form behavior

`POST /api/contact` accepts:

```ts
{
  intent: "demo" | "project" | "staffing" | "general",
  name: string,        // required
  email: string,       // required, validated
  organization?: string,
  // intent-specific fields validated server-side
  // ... see app/api/contact/route.ts for the full schema
}
```

The form pre-selects an intent when arriving with `?intent=demo` (or any other valid intent) in the URL. All "Book a demo" CTAs across the site use `/contact?intent=demo`.

Server-side protections:

- **Validation**: required fields per intent, email format check
- **Rate limit**: 5 submissions / hour / IP (in-memory; swap for Redis at scale)
- **Honeypot**: hidden `website` field — bot submissions are silently dropped
- **Reply-to**: emails arrive with the submitter's address as Reply-To, so you can just hit reply

## Deployment

### Vercel (recommended)

```bash
npm i -g vercel
vercel
# Set env vars in the Vercel dashboard (Production + Preview)
```

### Custom domain

1. Add `kouamvision.com` in Vercel project settings
2. Point DNS at Vercel (CNAME or A records)
3. SSL is automatic

## SEO checklist before launch

- [ ] Domain DNS pointed at Vercel
- [ ] `RESEND_API_KEY` + Resend domain verified
- [ ] Hero video files added to `/public`
- [ ] `og-image.png` added (1200×630)
- [ ] Favicon set
- [ ] Google Search Console verified, sitemap submitted
- [ ] Google Business Profile registered
- [ ] LinkedIn company page created and linked
- [ ] Test contact form end-to-end (all three intents)
- [ ] Lighthouse audit (mobile + desktop)

## Known things to revisit

- Footer "personal portfolio →" link points to `#` — update when portfolio site is live
- Email address in contact page (`hello@kouamvision.com`) is hardcoded — change in `app/contact/page.tsx` if needed
- LinkedIn link not in footer yet — add when company page exists
