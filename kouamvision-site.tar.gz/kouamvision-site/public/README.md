# Public assets needed

The hero section expects two video files and one poster image.
Drop these into this `/public` folder before deploying.

## Required files

| File              | Format           | Used for                                          |
|-------------------|------------------|---------------------------------------------------|
| `hero-bg.mp4`     | MP4 (H.264)      | Background video — primary source                 |
| `hero-bg.webm`    | WebM (VP9/AV1)   | Background video — modern browser fallback        |
| `hero-poster.jpg` | JPG (1920×1080+) | Static frame — shown while video loads, on mobile data-saver, and for users with `prefers-reduced-motion: reduce` |

## Encoding recommendations

Keep file sizes lean — this is a marketing hero, not a feature film.

```bash
# H.264 MP4 (broad compatibility, ~1–3 MB target)
ffmpeg -i source.mov -vf "scale=1920:-2,fps=24" -c:v libx264 -crf 28 -preset slow \
  -movflags +faststart -an hero-bg.mp4

# WebM (smaller files for modern browsers, ~0.7–2 MB target)
ffmpeg -i source.mov -vf "scale=1920:-2,fps=24" -c:v libvpx-vp9 -crf 35 -b:v 0 \
  -an hero-bg.webm

# Poster (extracted from video at frame 60, ~150 KB target)
ffmpeg -i hero-bg.mp4 -ss 00:00:02 -frames:v 1 -q:v 4 hero-poster.jpg
```

## Content suggestions for the hero video

For a Canadian tech firm with editorial/restrained brand:

- **Slow ambient motion**: aerial shots of Toronto, soft rain on glass, golden-hour light through trees, a single person at a laptop seen from above
- **Abstract/atmospheric**: ink in water, slow fog, paper texture, light on architecture
- **Studio motion**: hands typing, a single document being annotated, screens with movement that's intentionally vague enough not to date

Avoid: stock-feel "diverse team in glass meeting room", drone shots over generic skyscrapers, anything with visible UI/dashboards.

Sources for free licensed footage: Pexels, Coverr, Mixkit, Pixabay (verify license per clip).

## Other public assets to add eventually

- `/copilot-screenshot.png` (1600×1000 ideal, used on homepage Featured Work and `/work/copilot` hero)
- `/favicon.ico` (32×32)
- `/icon.png` (Next.js will use this for the modern icon)
- `/apple-icon.png` (180×180)
- `/og-image.png` (1200×630, used in social sharing previews)
